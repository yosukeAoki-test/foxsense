@extends('layouts.app')

@section('title', 'ユーザー編集')

@section('content')
<div class="container mx-auto px-4 py-6">
    <div class="max-w-2xl mx-auto">
        <div class="mb-6">
            <h1 class="text-3xl font-bold text-gray-800">ユーザー編集</h1>
            <p class="text-gray-600 mt-2">ユーザー「{{ $user->name }}」の情報を編集</p>
        </div>

        <!-- ユーザー統計 -->
        <div class="bg-blue-50 rounded-lg p-4 mb-6">
            <h3 class="text-lg font-semibold text-blue-800 mb-2">📊 ユーザー統計</h3>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <span class="text-blue-600">🔧 登録デバイス:</span>
                    <span class="font-semibold">{{ $user->devices_count }}台</span>
                </div>
                <div>
                    <span class="text-blue-600">✉️ 通知メール:</span>
                    <span class="font-semibold">{{ $user->user_emails_count }}件</span>
                </div>
                <div>
                    <span class="text-blue-600">📅 登録日:</span>
                    <span class="font-semibold">{{ $user->created_at->format('Y/m/d') }}</span>
                </div>
                <div>
                    <span class="text-blue-600">🔄 最終更新:</span>
                    <span class="font-semibold">{{ $user->updated_at->format('Y/m/d') }}</span>
                </div>
            </div>
        </div>

        <!-- 編集フォーム -->
        <div class="bg-white rounded-lg shadow p-6">
            <form method="POST" action="{{ route('admin.users.update', $user->id) }}">
                @csrf
                @method('PUT')
                
                <div class="space-y-6">
                    <!-- 名前 -->
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700 mb-1">名前</label>
                        <input type="text" 
                               name="name" 
                               id="name"
                               value="{{ old('name', $user->name) }}" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 @error('name') border-red-500 @enderror" 
                               required>
                        @error('name')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- メールアドレス -->
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-1">メールアドレス</label>
                        <input type="email" 
                               name="email" 
                               id="email"
                               value="{{ old('email', $user->email) }}" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 @error('email') border-red-500 @enderror" 
                               required>
                        @error('email')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- 管理者権限 -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">管理者権限</label>
                        <div class="space-y-2">
                            @if($canChangeAdminStatus)
                                <label class="flex items-center">
                                    <input type="hidden" name="is_admin" value="0">
                                    <input type="checkbox" 
                                           name="is_admin" 
                                           value="1" 
                                           {{ old('is_admin', $user->is_admin) ? 'checked' : '' }}
                                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                    <span class="ml-2 text-sm text-gray-700">管理者権限を付与する</span>
                                </label>
                                <p class="text-xs text-gray-500">
                                    管理者は全てのユーザーとデバイスにアクセスでき、システム管理機能を使用できます。
                                </p>
                            @else
                                <div class="bg-yellow-50 border border-yellow-200 rounded p-3">
                                    <div class="flex">
                                        <div class="flex-shrink-0">
                                            ⚠️
                                        </div>
                                        <div class="ml-3">
                                            <p class="text-sm text-yellow-800">
                                                自分自身の管理者権限は変更できません。
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="is_admin" value="{{ $user->is_admin ? '1' : '0' }}">
                            @endif
                        </div>
                    </div>

                    <!-- 注意事項 -->
                    @if($user->devices_count > 0 || $user->user_emails_count > 0)
                        <div class="bg-orange-50 border border-orange-200 rounded p-4">
                            <div class="flex">
                                <div class="flex-shrink-0">
                                    ℹ️
                                </div>
                                <div class="ml-3">
                                    <h3 class="text-sm font-medium text-orange-800">注意</h3>
                                    <p class="mt-2 text-sm text-orange-700">
                                        このユーザーには {{ $user->devices_count }}台のデバイスと {{ $user->user_emails_count }}件のメールアドレスが登録されています。
                                        ユーザー情報を変更しても、関連データは保持されます。
                                    </p>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>

                <!-- アクションボタン -->
                <div class="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
                    <a href="{{ route('admin.users') }}" 
                       class="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500">
                        ⬅️ 戻る
                    </a>
                    
                    <button type="submit" 
                            class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        💾 更新する
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection